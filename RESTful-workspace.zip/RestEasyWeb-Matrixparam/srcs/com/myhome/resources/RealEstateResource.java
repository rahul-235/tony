package com.myhome.resources;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/myhome")
public class RealEstateResource {

	/*
	 * @GET
	 * 
	 * @Path("{property}/{type}/{city}/{area}") public String
	 * getProperty(@PathParam("property") String property,
	 * 
	 * @PathParam("type") String type, @PathParam("city") String city,
	 * 
	 * @PathParam("area") String area) { String msg = "Property : " + property +
	 * "-- Type : " + type + "-- City : " + city + "-- Area:" + area; return
	 * msg; }
	 */

	@GET
	@Path("{property}/{type}/{city}/{area}")
	public String getProperty(@PathParam("property") String property,
			@PathParam("type") String type, @PathParam("city") String city,
			@PathParam("area") String area,@MatrixParam("syards") int syards) {
		String msg = "Property : " + property + "-- Type : " + type
				+ "-- City :" + city + "-- Area : " + area+"--square yards : "+syards;
		return msg;
	}
}
